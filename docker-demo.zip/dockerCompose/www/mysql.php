<?php
function test_conn_mysql(){
    $path = "mysql:dbname=mysql;host=mysql57;port=3306";
    $username = "root";
    $password = "123456";
    try{
        $db = new PDO($path,$username,$password);
    }catch(PDOException $e){
        die("Could not connect to the database:".$e);
    }
    $sql = "select * from user";
    $res = $db->prepare($sql);
    $res->execute();
 
    $result = $res->fetchAll();
    print_r($result);
}
test_conn_mysql();
?>